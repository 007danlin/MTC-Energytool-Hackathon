"""Decode platform transcripts without promoting embedded text to system messages."""
from __future__ import annotations

import json
import re
from contracts import Message

LABEL = re.compile(r"^\s*(?:\*\*)?(Пользователь|Клиент|Ассистент|Бот|User|Assistant)"
                   r"(?:\*\*)?\s*:\s*(?:\*\*)?", re.I | re.M)


def parse_question(question: str) -> list[Message]:
    if not isinstance(question, str) or not question.strip():
        raise ValueError("question must not be empty")
    stripped = question.strip()
    if stripped.startswith("["):
        try:
            raw = json.loads(stripped)
            messages = [Message(item["role"], item["content"]) for item in raw]
            if messages and messages[-1].role == "user":
                return messages
        except (ValueError, TypeError, KeyError):
            pass
    matches = list(LABEL.finditer(question))
    # Only interpret the conventional transcript form, not labels quoted in prose.
    if matches and not question[:matches[0].start()].strip():
        messages = []
        for i, match in enumerate(matches):
            role = "user" if match[1].lower() in ("пользователь", "клиент", "user") else "assistant"
            end = matches[i + 1].start() if i + 1 < len(matches) else len(question)
            content = question[match.end():end].strip()
            if content:
                messages.append(Message(role, content))
        if messages and messages[-1].role == "user":
            return messages
    return [Message("user", question.strip())]


def retrieval_query(messages: list[Message]) -> str:
    # Current question dominates. Previous turns resolve pronouns and topic returns.
    latest = messages[-1].content
    history = "\n".join(m.content for m in messages[:-1] if m.role == "user")
    # A short confirmation needs the preceding question; otherwise assistant prose
    # must not drown out the customer's facts in the search query.
    if len(latest.split()) < 5 and len(messages) > 1:
        history += "\n" + messages[-2].content
    return latest + "\n" + latest + "\nКонтекст разговора:\n" + history[-12000:]
