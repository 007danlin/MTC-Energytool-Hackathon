"""Replaceable lexical baseline; Artem can implement the Retriever protocol.

Reads every Markdown section at startup. No corpus, embeddings or index is shipped.
No calls to external services and no archive extraction to disk.
"""
from collections import Counter
from dataclasses import replace
import math
from pathlib import PurePosixPath
import re
from zipfile import ZipFile

from contracts import Fragment

STOP = set("это как что для или при уже есть нет нам вас ваш нас все так его она они мы вы и в на с по к из от до за а но у о ли бы не то же со во еще чем чтобы который какая какие можно нужно".split())
STOP.update("надо сначала потом вообще отдельно просто почти теперь только также да нет стоит сможете сможет можно можем хотите хотим хочу должен будут будет такие такой этого этом сего своего нашем вашей наша наш вашим увы работает работать поставит поставить менять изменит получится разберет увидеть видеть посмотреть сначала начать понимаем понял примерно около больше всего очень несколько которых благодаря сказать сказали вопрос подскажите расскажите пожалуйста пользователь ассистент контекст разговора".split())

# Vocabulary normalization only, never product facts or canned answers.
ALIASES = (
    (r"сим[ -]?карт|симк|\bsim\b", "simcard"),
    (r"крыш|кровл", "roof"),
    (r"фасад|вертикальн", "facade"),
    (r"расшир|наращ|нараст|поэтап|очеред", "expansion"),
    (r"магазин|ретейл|ритейл", "retail"),
    (r"двухтариф|многотариф|тарифн[а-я]*\s+зон|раздельно\s+по\s+тариф", "multitariff"),
    (r"фото|изображен|снимк", "photo"),
    (r"счетчик|прибор[а-я]*\s+учет", "meter"),
    (r"компенс[а-я]*\s+реактив|реактивн", "reactive"),
    (r"провер[а-я]*\s+(?:наш|существующ|действующ)?[а-я ]*учет|аудит", "audit"),
)


def tokens(text):
    text = text.lower().replace("ё", "е")
    words = re.findall(r"[а-яa-z0-9]+", text)
    result = ["@" + canonical for pattern, canonical in ALIASES if re.search(pattern, text)]
    for word in words:
        if word in STOP or len(word) < 2:
            continue
        result.append(word)
        if len(word) >= 5 and re.search("[а-я]", word):
            result.append("~" + word[:5])
    return result


def load_fragments(archive_path):
    fragments = []
    with ZipFile(archive_path) as archive:
        members = [m for m in archive.infolist()
                   if not m.is_dir() and PurePosixPath(m.filename).suffix.lower() in (".md", ".txt")
                   and not any(p.startswith((".", "__MACOSX")) for p in PurePosixPath(m.filename).parts)]
        if len(members) > 2000 or sum(m.file_size for m in members) > 50_000_000:
            raise ValueError("Knowledge base exceeds size limit")
        names = set()
        for member in sorted(members, key=lambda m: m.filename):
            name = member.filename
            if (PurePosixPath(name).is_absolute() or ".." in PurePosixPath(name).parts
                    or "\\" in name or name in names or member.file_size > 5_000_000):
                raise ValueError("Invalid knowledge base member")
            names.add(name)
            text = archive.read(member).decode("utf-8-sig")
            text = text.replace("\\## ", "\n## ")
            heading = []
            section = []
            counter = 0

            def emit():
                nonlocal counter
                body = "\n".join(section).strip()
                if not body:
                    return
                title = " > ".join(heading)
                # Keep ordinary sections/tables intact. Split only very long sections.
                while body:
                    cut = min(len(body), 4800)
                    if cut < len(body):
                        boundary = body.rfind("\n\n", 1800, cut)
                        if boundary > 0:
                            cut = boundary
                    piece, body = body[:cut].strip(), body[cut:].lstrip()
                    counter += 1
                    fragments.append(Fragment(name, f"s{counter:03d}", title + "\n" + piece))

            for line in text.splitlines():
                match = re.match(r"^(#{1,6})\s+(.+)", line)
                if match:
                    emit()
                    section = []
                    level = len(match[1])
                    heading = heading[:level - 1] + [match[2]]
                elif not re.fullmatch(r"\s*-{8,}\s*", line):
                    section.append(line)
            emit()
    if not fragments:
        raise ValueError("Knowledge base has no readable Markdown/text content")
    return fragments


class LexicalRetriever:
    """BM25 with lightweight Russian prefix matching and constraint sections."""
    def __init__(self, fragments):
        self.fragments = tuple(fragments)
        self.counts = [Counter(tokens(f.text)) for f in self.fragments]
        self.lengths = [sum(c.values()) for c in self.counts]
        self.average = sum(self.lengths) / max(1, len(self.lengths))
        self.df = Counter(token for counts in self.counts for token in counts)

    @classmethod
    def from_zip(cls, path):
        return cls(load_fragments(path))

    def search(self, query, top_k=12):
        query_counts = Counter(tokens(query))
        scores = []
        total = len(self.fragments)
        for i, counts in enumerate(self.counts):
            score = 0.0
            for token, weight in query_counts.items():
                freq = counts.get(token, 0)
                if not freq:
                    continue
                idf = math.log(1 + (total - self.df[token] + 0.5) / (self.df[token] + 0.5))
                denominator = freq + 1.5 * (0.25 + 0.75 * self.lengths[i] / max(1, self.average))
                boost = (0.55 if token.startswith("~") else
                         1.0 if token == "@meter" else
                         2.0 if token == "@photo" else
                         5.0 if token.startswith("@") else 1.0)
                score += idf * freq * 2.5 / denominator * min(weight, 3) * boost
            if score:
                scores.append((score, i))
        scores.sort(key=lambda item: (-item[0], self.fragments[item[1]].source_id))
        selected = [replace(self.fragments[i], score=round(score, 4)) for score, i in scores[:top_k]]
        # Companion restrictions prevent isolated attractive numbers losing their caveats.
        primary_docs = list(dict.fromkeys(f.document_id for f in selected[:4]))[:2]
        guards = []
        for document in primary_docs:
            guards.extend(f for f in self.fragments if f.document_id == document
                          and any(heading in f.text.split("\n", 1)[0] for heading in
                                  ("Чего утверждать нельзя", "Что нужно от клиента", "Важное ограничение", "Не подходит, если")))
        # Small reference sheets retain cross-product boundaries and required inputs.
        # These are read from the supplied archive, never embedded in the submission.
        support = [f for f in self.fragments if f.document_id.startswith("00-reference/")
                   and not f.document_id.endswith("01-numbers-and-indicators.md")]
        result, seen = [], set()
        for fragment in selected + guards + support:
            if fragment.source_id not in seen:
                result.append(fragment)
                seen.add(fragment.source_id)
        return result


class FixedRetriever:
    """For manual real-KB fragments or deterministic integration tests."""
    def __init__(self, fragments):
        self.fragments = tuple(fragments)

    def search(self, query, top_k=12):
        return self.fragments[:top_k]
