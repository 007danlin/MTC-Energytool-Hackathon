"""Answer generation for one CSV row. Every row is independent; no state of a dialogue is shared."""
from dataclasses import asdict
import json
import re
import threading
import time

from dialogue import parse_question, retrieval_query
from dialogue_n1 import parse_dialogue
from llm_client import ModelError
from prompts import DOCUMENTS_HEADER, HIGHLIGHT_HEADER, REFERENCE_HEADER, system_prompt, user_prompt
from prompts_a2 import ANSWER_PROMPT as A2_PROMPT
from retrieval import WideRetriever
from retrieval_a2 import LexicalRetriever, load_fragments

# Used only by the A2 control mode, byte-for-byte the A2 text.
TECHNICAL_ANSWER = ("Сейчас не удалось получить ответ модели из-за технического сбоя. "
                    "Это не означает, что информации нет в базе знаний. "
                    "Попробуйте повторить вопрос позже; заявку пока не отправляли.")
LAST_RESORT = ("Чтобы ответить точно, нам нужно немного больше сведений о вашей задаче и объекте: тип организации, "
               "присоединённая мощность и то, что уже установлено из приборов учёта. Расскажите, пожалуйста, подробнее — "
               "или оставьте телефон, и вопрос разберёт специалист МТС EnergyTool.")
META_HEADINGS = ("Чего утверждать нельзя", "Факты, которые можно утверждать", "Что мы не делаем", "Следующий шаг")


def sanitize_delivery_a2(answer):
    """A2 behaviour, kept only for the control mode."""
    sent_claim = re.search(r"(?:заявк\w*\s+(?:успешно\s+)?(?:отправлен|передан)|"
                           r"(?:отправил|передал)\w*\s+(?:ваш\w*\s+)?заявк)", answer, re.I)
    if sent_claim:
        answer = re.sub(r"[^.!?\n]*" + re.escape(sent_claim.group(0)) + r"[^.!?\n]*[.!?]?",
                        "Заявку можно подготовить; отправки менеджеру пока нет.", answer, flags=re.I)
    return answer.strip()


def unwrap(answer):
    """Tolerate an answer wrapped in a code fence or a {"answer": ...} object."""
    candidate = re.sub(r"^```(?:json)?\s*|\s*```$", "", answer.strip(), flags=re.I).strip()
    if candidate.startswith("{"):
        try:
            wrapper = json.loads(candidate)
            if isinstance(wrapper, dict) and isinstance(wrapper.get("answer"), str):
                return wrapper["answer"].strip()
        except (ValueError, TypeError):
            pass
    return candidate if candidate else answer.strip()


def polish(answer):
    """Plain single-paragraph text, without role labels or markup; no claim that a lead was sent."""
    text = unwrap(answer)
    text = re.sub(r"^\s*(?:\*\*)?(?:Консультант|Ассистент|Ответ|Assistant)(?:\*\*)?\s*:\s*", "", text, flags=re.I)
    text = re.sub(r"\*\*|__|`", "", text)
    text = re.sub(r"(?m)^\s*(?:[-•*]|\d+[.)])\s+", "", text)
    text = re.sub(r"(?m)^\s*#{1,6}\s*", "", text)
    text = " ".join(text.split())
    if len(text) > 1 and text[0] in "«\"“" and text[-1] in "»\"”" and text.count(text[0]) == 1:
        text = text[1:-1].strip()
    text = re.sub(r"\b([Зз]аявка)\s+(?:уже\s+|успешно\s+)*(?:отправлена|передана)\b", r"\1 сформирована", text)
    text = re.sub(r"\b(отправил|передал)(а?)\s+((?:ваш\w*\s+)?заявк\w+)", r"сформировал\2 \3", text)
    if len(text) > 9900:
        cut = max(text.rfind(". ", 0, 9900), text.rfind("? ", 0, 9900), text.rfind("! ", 0, 9900))
        text = text[:cut + 1] if cut > 0 else text[:9900]
    return text.strip()


LADDER = ("full", "docs", "wide")


class RunState:
    """Shared, thread-safe switches learned during one run."""
    def __init__(self, start):
        self._lock = threading.Lock()
        self.level = LADDER.index(start) if start in LADDER else len(LADDER) - 1
        self.start_level = self.level
        self.fast = False
        self.soft_failures = 0

    def mode(self):
        with self._lock:
            return LADDER[self.level]

    def step_down(self, from_mode, hard=False, weight=1):
        """A large context was refused (hard) or repeatedly unusable: use the next smaller one.

        A refusal steps down at once; two timeouts or three token-limited answers do the same.
        """
        with self._lock:
            if from_mode not in LADDER or LADDER.index(from_mode) != self.level or self.level >= len(LADDER) - 1:
                return
            self.soft_failures += weight
            if hard or self.soft_failures >= 3:
                self.level += 1
                self.soft_failures = 0

    def hurry(self):
        with self._lock:
            self.fast = True
            self.level = len(LADDER) - 1


class Consultant:
    def __init__(self, client, knowledge_path, settings):
        self.client, self.settings = client, settings
        self.fragments = tuple(load_fragments(knowledge_path))
        self.a2 = LexicalRetriever(self.fragments)
        self.wide = WideRetriever(self.fragments)
        self.state = RunState(settings.context)
        self.reference = self.wide.reference()
        self.system_compact = system_prompt(fewshot=settings.fewshot)
        self.system_full = self.system_docs = None
        if settings.prompt == "n1" and settings.context == "full":
            self.system_full = system_prompt(fewshot=settings.fewshot, knowledge=self.fragments)
        if settings.prompt == "n1" and settings.context in ("full", "docs"):
            self.system_docs = system_prompt(fewshot=settings.fewshot, knowledge=self.reference, header=REFERENCE_HEADER)

    # ---- context ---------------------------------------------------------------
    def _a2_sources(self, query):
        chosen, used, seen = [], 0, set()
        for fragment in self.a2.search(query, self.settings.top_k):
            if fragment.source_id in seen or not fragment.text.strip():
                continue
            if used + len(fragment.text) > self.settings.context_chars:
                continue
            chosen.append(fragment)
            seen.add(fragment.source_id)
            used += len(fragment.text)
        return chosen

    def _doc_sources(self, query):
        return self.wide.search_documents(query, self.settings.doc_count, self.settings.doc_k, self.settings.doc_chars)

    def _wide_sources(self, query, compact=False):
        if compact:
            return self.wide.search(query, max(4, self.settings.wide_k - 3), min(self.settings.wide_chars, 9000))
        return self.wide.search(query, self.settings.wide_k, self.settings.wide_chars)

    def _build(self, messages, query, mode, *, fast=False, compact=False):
        """Return (chat messages, number of context characters) for a context mode."""
        if self.settings.prompt == "a2":
            sources = (self._a2_sources(query) if mode == "a2" else
                       list(self.fragments) if mode == "full" else
                       self.reference + self._doc_sources(query) if mode == "docs" else
                       self._wide_sources(query, compact))
            context = {"messages": [{"index": i, **asdict(m)} for i, m in enumerate(messages)],
                       "sources": [{"source_id": f.source_id, "text": f.text} for f in sources]}
            return ([{"role": "system", "content": A2_PROMPT},
                     {"role": "user", "content": json.dumps(context, ensure_ascii=False)}],
                    sum(len(f.text) for f in sources))
        if mode == "full":
            highlight = self.wide.ordered(self.wide.search(query, 8, 9000))
            return ([{"role": "system", "content": self.system_full},
                     {"role": "user", "content": user_prompt(messages, highlight, header=HIGHLIGHT_HEADER, fast=fast)}],
                    sum(len(f.text) for f in self.fragments))
        if mode == "docs":
            sources = self._doc_sources(query)
            return ([{"role": "system", "content": self.system_docs},
                     {"role": "user", "content": user_prompt(messages, sources, header=DOCUMENTS_HEADER, fast=fast)}],
                    sum(len(f.text) for f in sources) + sum(len(f.text) for f in self.reference))
        sources = self._a2_sources(query) if mode == "a2" else self._wide_sources(query, compact)
        if mode != "a2":
            sources = self.wide.ordered(sources)
        return ([{"role": "system", "content": self.system_compact},
                 {"role": "user", "content": user_prompt(messages, sources, fast=fast)}],
                sum(len(f.text) for f in sources))

    # ---- generation --------------------------------------------------------------
    def answer(self, question, *, deadline=None):
        """Return (answer, info). `info` holds only safe metadata for diagnostics."""
        cfg = self.settings
        info = {"status": "ok", "mode": cfg.context, "calls": 0, "finish": "", "reasoning_chars": 0,
                "completion_tokens": 0, "context_chars": 0, "error": None}
        try:
            # The control mode keeps the A2 parser; the N1 modes also read other speaker labels.
            messages = parse_question(question) if cfg.control else parse_dialogue(question)
            query = retrieval_query(messages)
        except Exception:
            info.update(status="input_error", error="parse")
            return (TECHNICAL_ANSWER if not cfg.rescue else LAST_RESORT), info

        def call(mode, *, fast=False, compact=False, reasoning=None, max_tokens=None):
            chat, chars = self._build(messages, query, mode, fast=fast, compact=compact)
            info["calls"] += 1
            info["mode"], info["context_chars"] = mode, chars
            done = self.client.chat(chat, deadline=deadline,
                                    max_tokens=cfg.main_max_tokens if max_tokens is None else max_tokens,
                                    reasoning=cfg.reasoning if reasoning is None else reasoning,
                                    attempts=2 if mode in ("full", "docs") else None,
                                    timeout=cfg.big_timeout if mode in ("full", "docs") else None)
            info.update(finish=done.finish_reason, reasoning_chars=done.reasoning_chars,
                        completion_tokens=done.completion_tokens)
            return done

        if not cfg.rescue:
            return self._control(call, info)

        fast = self.state.fast
        mode = self.state.mode() if cfg.context in LADDER else cfg.context
        main = dict(mode=mode, fast=fast, reasoning="off" if fast else None)
        # Recovery steps for a token-limited or empty generation: short context, brief reasoning.
        queue = [main,
                 dict(mode="wide", fast=True, compact=True, reasoning="off"),
                 dict(mode="wide", fast=True, compact=True, reasoning="default",
                      max_tokens=min(max(cfg.main_max_tokens * 2, 4096), 8192))]
        partial, steps = "", 0
        while queue and steps < 5:
            options = queue.pop(0)
            steps += 1
            if deadline is not None and time.monotonic() >= deadline:
                info.update(status="deadline", error="deadline_exceeded")
                break
            try:
                done = call(**options)
            except ModelError as exc:
                info["error"] = exc.code
                if exc.code == "deadline_exceeded":
                    info["status"] = "deadline"
                    break
                if exc.status in (401, 403):
                    break  # an access error will not heal within this row
                refused = exc.context_overflow or exc.code == "bad_request"
                if options["mode"] in LADDER[:-1] and "compact" not in options:
                    # The service did not take a large context: same row, next smaller context, normal settings.
                    self.state.step_down(options["mode"], hard=refused, weight=2 if exc.code == "transport_error" else 1)
                    if refused:
                        smaller = LADDER[LADDER.index(options["mode"]) + 1]
                        queue.insert(0, dict(mode=smaller, fast=fast, reasoning="off" if fast else None))
                continue
            if done.usable:
                text = polish(done.content)
                if text:
                    info["status"] = "ok" if options is main else "recovered"
                    info["error"] = None
                    return text, info
            info["error"] = "truncated" if done.truncated else "empty"
            if done.truncated and len(done.content.split()) >= 12:
                partial = done.content
            if done.truncated:
                self.state.step_down(options["mode"])
        if partial:
            # A token-limited answer cut at its last complete sentence is still the model's own grounded text.
            text = polish(partial)
            cut = max(text.rfind(". "), text.rfind("? "), text.rfind("! "))
            if cut > 40:
                info["status"] = "partial"
                return text[:cut + 1], info
        info["status"] = "fallback" if info["status"] != "deadline" else "deadline_fallback"
        return self.extract(query), info

    def _control(self, call, info):
        """A2 policy: the same request is repeated only for empty content; no recovery."""
        cfg = self.settings
        mode = cfg.context
        for _ in range(cfg.attempts):
            try:
                done = call(mode)
            except ModelError as exc:
                info.update(status="technical_error", error=exc.code)
                return TECHNICAL_ANSWER, info
            if done.truncated:
                info.update(status="technical_error", error="truncated_response")
                return TECHNICAL_ANSWER, info
            if done.content:
                if cfg.prompt == "a2":
                    # Exactly the A2 post-processing: only a parsed JSON wrapper replaces the text.
                    answer = done.content.strip()
                    candidate = re.sub(r"^```(?:json)?\s*|\s*```$", "", answer, flags=re.I).strip()
                    if candidate.startswith("{"):
                        try:
                            wrapper = json.loads(candidate)
                            if isinstance(wrapper, dict) and isinstance(wrapper.get("answer"), str):
                                answer = wrapper["answer"].strip()
                        except (ValueError, TypeError):
                            pass
                    answer = sanitize_delivery_a2(answer)
                else:
                    answer = polish(done.content)
                if answer and len(answer) <= 10000:
                    return answer, info
                info.update(status="technical_error", error="invalid_answer_length")
                return TECHNICAL_ANSWER, info
        info.update(status="technical_error", error="empty_response")
        return TECHNICAL_ANSWER, info

    # ---- last resort without the model -----------------------------------------------
    def extract(self, query):
        """A grounded excerpt of the closest FAQ-style section; never a technical placeholder."""
        try:
            for index in self.wide.rank(query)[:12]:
                fragment = self.wide.fragments[index]
                heading, _, body = fragment.text.partition("\n")
                if any(h in heading for h in META_HEADINGS) or "-----" in body or "|" in body:
                    continue
                if not fragment.document_id.startswith("20-products/") and "17-faq" not in fragment.document_id:
                    continue
                text = " ".join(re.sub(r"\*\*|`|\[|\]\([^)]*\)", "", body).split())
                sentences = re.findall(r"[^.!?]+[.!?]", text)
                excerpt = ""
                for sentence in sentences:
                    if len((excerpt + sentence).split()) > 55:
                        break
                    excerpt += sentence
                if len(excerpt.split()) >= 8:
                    return (excerpt.strip() + " Чтобы ответить точнее по вашей ситуации, расскажите, пожалуйста, "
                            "подробнее об объекте и задаче.")
        except Exception:
            pass
        return LAST_RESORT
